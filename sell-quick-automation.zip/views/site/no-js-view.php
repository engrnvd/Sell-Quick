<div class="heading-panel">
    <h1>No Javascript? :(</h1>
    <h2>Sorry, You don't seem to have javascript enabled</h2>
    <h3>The content here requires you to have javascript enabled.</h3>
    <p>Either you have javascript disabled or your browser is not configured properly. Please refer to your browser settings and enable javascript.</p>
</div>

<br/><br/><br/><br/><br/><br/><br/><br/>