<section class="bottom-form-bg">

    <div class="container">

        <h2>Are you selling your property?</h2>

        <h4>Get a <strong>FREE</strong> valuation and cash offer</h4>

        <div class="clear"></div>

        <div class="form-box">

            <div class="form-inner">

                <?php new \app\components\ValuationFormWidget( $formModel, ['horizontal' => true,] ); ?>

                <div class="clear"></div>

            </div><!--form-inner-->

        </div><!--form-box-->

    </div><!--container-->

</section><!--bottom form bg-->