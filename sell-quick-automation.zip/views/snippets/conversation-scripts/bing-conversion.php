<script type="text/javascript">
    if (!window.mstag)
        mstag = {loadTag: function() {
            }, time: (new Date()).getTime()};
</script> 
<script id="mstag_tops" type="text/javascript" src="//flex.atdmt.com/mstag/site/d13d741f-a973-4b9d-8c8e-76e2951e9685/mstag.js">
</script> 
<script type="text/javascript">
    mstag.loadTag("analytics", {dedup: "1", domainId: "355616", type: "1", actionid: "110876"})
</script> 
<noscript> 
<iframe src="//flex.atdmt.com/mstag/tag/d13d741f-a973-4b9d-8c8e-76e2951e9685/analytics.html?dedup=1&domainId=355616&type=1&actionid=110876" frameborder="0" scrolling="no" width="1" height="1" style="visibility:hidden;display:none"> 
</iframe> 
</noscript>