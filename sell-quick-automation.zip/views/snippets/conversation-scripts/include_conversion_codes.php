<?php
/**
 * Created by Naveed-ul-Hassan Malik
 * Date: 5/15/2015
 * Time: 6:36 PM
 */

require_once __DIR__."/bing-conversion.php";
require_once __DIR__."/fb-conversion.php";
require_once __DIR__."/google-conversion.php";