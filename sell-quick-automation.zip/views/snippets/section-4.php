<section class="customer-bg">

    <h2>What Our Customers Say...</h2>

    <div class="padding0">

        <div class="col-lg-4 col-sm-4">

            <div class="testimonial-box">

                <p>You kept in touch from start to finish and explained things so I could understand. If I phoned to ask a question it was always answered. I can whole-heartedly recommend Sell Quick, I just said I’d sell and everything was taken care of. The staff are first rate at what they do.</p>

            </div><!--testimonial-box-->

            <div class="quote-info">

                <p>
                    <a href="#">Mr and Mrs Benson, </a><br />
                    County Durham.
                </p>

            </div><!--quote-info-->

        </div><!--col lg sm 4-->

        <div class="col-lg-4 col-sm-4">

            <div class="testimonial-box">

                <p>You kept in touch from start to finish and explained things so I could understand. If I phoned to ask a question it was always answered. I can whole-heartedly recommend Sell Quick, I just said I’d sell and everything was taken care of. The staff are first rate at what they do.</p>

            </div><!--testimonial-box-->

            <div class="quote-info">

                <p>
                    <a href="#">Mr and Mrs Benson, </a><br />
                    County Durham.
                </p>

            </div><!--quote-info-->

        </div><!--col lg sm 4-->

        <div class="col-lg-4 col-sm-4">

            <div class="testimonial-box">

                <p>You kept in touch from start to finish and explained things so I could understand. If I phoned to ask a question it was always answered. I can whole-heartedly recommend Sell Quick, I just said I’d sell and everything was taken care of. The staff are first rate at what they do.</p>

            </div><!--testimonial-box-->

            <div class="quote-info">

                <p>
                    <a href="#">Mr and Mrs Benson, </a><br />
                    County Durham.
                </p>
            </div><!--quote-info-->

        </div><!--col lg sm 4-->

        <div class="clear"></div>

    </div><!--col lg 12-->

</section><!--section 4-->