<h5 style="line-height:24px; margin:0px !important;">During your free, no-obligation appointment. Our Local Property Valuer will:</h5>
<div class="list-style margintop10">
    <ul>
        <li>Provide you with a valuation estimation for your property</li>
        <li>Be friendly, professional and knowledgeable</li>
        <li>Answer any questions that you have with regards to the sale of your property</li>
        <li>Explain the best way to achieve full market value for your property quickly</li>
        <li>Take some photos of your property if you decide to use our services</li>
    </ul>
</div><!--list style-->